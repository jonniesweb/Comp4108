/* This file is auto generated, version 121+test1 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#121+test1 SMP Mon Feb 1 19:20:00 UTC 2016"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "eccb164e3fa5"
#define LINUX_COMPILER "gcc version 4.8.4 (Ubuntu 4.8.4-2ubuntu1~14.04) "
